package com.springboot.financialplanning.repository;

public class CustomQueriesTest {

}
