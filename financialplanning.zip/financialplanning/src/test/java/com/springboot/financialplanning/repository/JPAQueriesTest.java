package com.springboot.financialplanning.repository;

import org.springframework.beans.factory.annotation.Autowired;

public class JPAQueriesTest {
	
	@Autowired
	InsuranceRepository insuranceRepository;
	
	

}
