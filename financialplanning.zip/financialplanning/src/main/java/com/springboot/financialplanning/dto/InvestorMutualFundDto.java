package com.springboot.financialplanning.dto;

public class InvestorMutualFundDto {
	private Double amountInvested;
	

	public Double getAmountInvested() {
		return amountInvested;
	}

	public void setAmountInvested(Double amountInvested) {
		this.amountInvested = amountInvested;
	}
	
	
}
