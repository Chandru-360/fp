package com.springboot.financialplanning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancialplanningApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinancialplanningApplication.class, args);
	}

}
