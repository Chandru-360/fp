package com.springboot.financialplanning.dto;

public class InvestorInsuranceDto {

}
