package com.enums;

public enum InvestmentType {
SIP,ONE_TIME,MONTHLY,YEARLY
}
