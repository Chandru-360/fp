package com.enums;

public enum Role {
	INVESTOR,COMPANY,EXECUTIVE,SALES_VP,
	HR
}
