package com.enums;

public enum Category {
   LIFE,HEALTH,HIGH_CAP,MID_CAP,LOW_CAP,LOGISTICS,DIGITAL_INDIA,HEALTHCARE
}
