package com.enums;

public enum RickFactor {
	HIGH,MEDIUM,LOW
}